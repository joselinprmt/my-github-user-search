package com.dicoding.mystoryapp.view.auth.login

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.closeSoftKeyboard
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.intent.Intents
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import com.dicoding.mystoryapp.BuildConfig
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.util.EspressoIdlingResource
import com.dicoding.mystoryapp.view.main.MainActivity
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@LargeTest
class LoginActivityTest {

    @get:Rule
    val activity = ActivityScenarioRule(MainActivity::class.java)

    @Before
    fun setUp() {
        IdlingRegistry.getInstance().register(EspressoIdlingResource.countingIdlingResource)
        Intents.init()
    }

    @After
    fun tearDown() {
        Intents.release()
        IdlingRegistry.getInstance().unregister(EspressoIdlingResource.countingIdlingResource)
    }

    @Test
    fun loginAndLogout_success() {
        val email = BuildConfig.EMAIL_TEST
        val password = BuildConfig.PASSWORD_TEST

        onView(withId(R.id.loginButton)).check(matches(isDisplayed()))
        onView(withId(R.id.loginButton)).perform(click())

        onView(withId(R.id.ed_login_email)).check(matches(isDisplayed()))
        onView(withId(R.id.ed_login_email)).perform(
            ViewActions.typeText(email),
            closeSoftKeyboard()
        )
        onView(withId(R.id.ed_login_password)).check(matches(isDisplayed()))
        onView(withId(R.id.ed_login_password)).perform(
            ViewActions.typeText(password),
            closeSoftKeyboard()
        )
        onView(withId(R.id.button_login)).check(matches(isDisplayed()))
        onView(withId(R.id.button_login)).perform(click())
        Thread.sleep(8000) // Play animations

        onView(withId(R.id.list_story_button)).check(matches(isDisplayed()))
        onView(withId(R.id.maps_button)).check(matches(isDisplayed()))
        onView(withId(R.id.action_logout)).check(matches(isDisplayed()))
        onView(withId(R.id.action_logout)).perform(click())

        onView(withText(R.string.title_welcome_page)).check(matches(isDisplayed()))
    }
}