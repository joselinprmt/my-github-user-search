package com.dicoding.mystoryapp.data.local.pref

data class User (
    val email: String,
    val name: String,
    val token: String,
    val isLogin: Boolean = false
)
