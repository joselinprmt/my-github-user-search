package com.dicoding.mystoryapp.data.di

import android.content.Context
import com.dicoding.mystoryapp.data.local.database.StoryItemDatabase
import com.dicoding.mystoryapp.data.local.pref.UserPreference
import com.dicoding.mystoryapp.data.local.pref.dataStore
import com.dicoding.mystoryapp.data.remote.retrofit.ApiConfig
import com.dicoding.mystoryapp.data.repository.StoryRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object StoryInjection {
    fun provideRepository(context: Context): StoryRepository {

        val pref = UserPreference.getInstance(context.dataStore)
        val user = runBlocking { pref.getUser().first() }
        val apiService = ApiConfig.getApiService()
        val storyDatabase = StoryItemDatabase.getDatabase(context)

        return StoryRepository.getInstance(apiService, storyDatabase, user.token)
    }
}