package com.dicoding.mystoryapp.view.story.map

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.mystoryapp.data.remote.response.StoryItem
import com.dicoding.mystoryapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class MapsViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    val isLoading = MutableLiveData<Boolean>()
    private val stories = MutableLiveData<List<StoryItem?>>()

    fun getStoriesWithLocation() {
        isLoading.value = true

        viewModelScope.launch {
            stories.value = storyRepository.getStoriesWithLocation()
            isLoading.value = false
        }
    }

    fun setMarker(): MutableLiveData<List<StoryItem?>> {
        return stories
    }
}