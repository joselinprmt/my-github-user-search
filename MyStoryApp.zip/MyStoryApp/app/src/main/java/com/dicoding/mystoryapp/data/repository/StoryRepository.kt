package com.dicoding.mystoryapp.data.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.mystoryapp.data.ResultState
import com.dicoding.mystoryapp.data.StoryRemoteMediator
import com.dicoding.mystoryapp.data.local.database.StoryItemDatabase
import com.dicoding.mystoryapp.data.remote.response.FileUploadResponse
import com.dicoding.mystoryapp.data.remote.response.StoryItem
import com.dicoding.mystoryapp.data.remote.retrofit.ApiService
import com.dicoding.mystoryapp.util.wrapEspressoIdlingResource
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class StoryRepository (
    private val apiService: ApiService,
    private val storyItemDatabase: StoryItemDatabase,
    private val token: String,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {

    fun getStories(): LiveData<PagingData<StoryItem>> {
        @OptIn(ExperimentalPagingApi::class)
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            remoteMediator = StoryRemoteMediator("Bearer $token", storyItemDatabase, apiService),
            pagingSourceFactory = {
                storyItemDatabase.storyItemDao().getAllStory()
            }
        ).liveData
    }

    suspend fun getStoriesWithLocation(): List<StoryItem?>? {
        return withContext(dispatcher) {
            try {
                val response = apiService.getStoriesWithLocation("Bearer $token")
                response.listStory
            } catch (e: Exception) {
                Log.e(TAG, "getStoriesWithLocation: ${e.message}", e)
                emptyList()
            }
        }
    }

    fun uploadStory(imageFile: File, description: String, currentLat: Float?, currentLon: Float?) = liveData {
        emit(ResultState.Loading)
        wrapEspressoIdlingResource {
            try {
                val requestBody = description.toRequestBody("text/plain".toMediaType())
                val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
                val requestLat = currentLat?.toString()?.toRequestBody("text/plain".toMediaType())
                val requestLon = currentLon?.toString()?.toRequestBody("text/plain".toMediaType())
                val multipartBody = MultipartBody.Part.createFormData(
                    "photo",
                    imageFile.name,
                    requestImageFile
                )
                val successResponse =
                    apiService.uploadStory("Bearer $token", multipartBody, requestBody, requestLat, requestLon)

                emit(ResultState.Success(successResponse))

            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                val errorResponse = Gson().fromJson(errorBody, FileUploadResponse::class.java)

                emit(ResultState.Error(errorResponse.message))
            }
        }
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null
        fun getInstance(apiService: ApiService,
                        storyItemDatabase: StoryItemDatabase,
                        token: String): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(apiService, storyItemDatabase, token)
            }.also { instance = it }

        private const val TAG = "StoryRepository"
    }
}