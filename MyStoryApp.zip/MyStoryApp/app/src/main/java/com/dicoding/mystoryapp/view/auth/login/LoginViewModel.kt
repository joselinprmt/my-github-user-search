package com.dicoding.mystoryapp.view.auth.login

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.dicoding.mystoryapp.data.local.pref.User
import com.dicoding.mystoryapp.data.remote.response.LoginResponse
import com.dicoding.mystoryapp.data.remote.retrofit.ApiConfig
import com.dicoding.mystoryapp.data.repository.UserRepository
import com.dicoding.mystoryapp.util.wrapEspressoIdlingResource
import com.google.gson.Gson
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginViewModel(private val repository: UserRepository) : ViewModel() {
    val isLoading = MutableLiveData<Boolean>()
    val fetchedResponse = MutableLiveData<LoginResponse>()

    companion object{
        private const val TAG = "LoginViewModel"
    }

    fun login(email: String, password: String) {
        wrapEspressoIdlingResource {
            isLoading.value = true
            val client = ApiConfig.getApiService().login(email, password)
            client.enqueue(object : Callback<LoginResponse> {
                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {
                    isLoading.value = false
                    if (response.isSuccessful) {
                        fetchedResponse.value = response.body()

                        val name = response.body()?.loginResult?.name.toString()
                        val token = response.body()?.loginResult?.token.toString()
                        saveSession(User(email, name, token, isLogin = true))

                    } else {
                        val errorBody = response.errorBody()?.string()
                        if (errorBody != null) {
                            try {
                                val gson = Gson()
                                val errorResponse =
                                    gson.fromJson(errorBody, LoginResponse::class.java)
                                fetchedResponse.value = errorResponse
                                Log.e(TAG, "onFailure: ${errorResponse.message}")
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to parse error body", e)
                            }
                        } else {
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    isLoading.value = false
                    Log.e(TAG, "onFailure: ${t.message.toString()}")
                }
            })
        }
    }

    fun getSession() : LiveData<User> {
        return repository.getSession().asLiveData()
    }

    fun saveSession(user: User) {
        viewModelScope.launch {
            repository.saveSession(user)
        }
    }
}