package com.dicoding.mystoryapp.data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dicoding.mystoryapp.data.remote.response.StoryItem

@Database(
    entities = [StoryItem::class, RemoteKeys::class],
    version = 1,
    exportSchema = false
)
abstract class StoryItemDatabase : RoomDatabase() {

    abstract fun storyItemDao(): StoryItemDao
    abstract fun remoteKeysDao(): RemoteKeysDao

    companion object {
        @Volatile
        private var INSTANCE: StoryItemDatabase? = null

        @JvmStatic
        fun getDatabase(context: Context): StoryItemDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StoryItemDatabase::class.java, "story_item_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}