package com.dicoding.mystoryapp.data.local.database

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dicoding.mystoryapp.data.remote.response.StoryItem

@Dao
interface StoryItemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: List<StoryItem?>?)

    @Query("SELECT * FROM STORY_ITEM")
    fun getAllStory(): PagingSource<Int, StoryItem>

    @Query("DELETE FROM STORY_ITEM")
    suspend fun deleteAll()
}