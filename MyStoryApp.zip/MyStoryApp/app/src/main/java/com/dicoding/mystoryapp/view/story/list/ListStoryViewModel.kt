package com.dicoding.mystoryapp.view.story.list

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.mystoryapp.data.remote.response.StoryItem
import com.dicoding.mystoryapp.data.repository.StoryRepository

class ListStoryViewModel(storyRepository: StoryRepository) : ViewModel() {
    val stories: LiveData<PagingData<StoryItem>> =
        storyRepository.getStories().cachedIn(viewModelScope)
}