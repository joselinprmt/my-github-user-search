package com.dicoding.mystoryapp.view.story.upload

import android.net.Uri
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.mystoryapp.data.repository.StoryRepository
import java.io.File

class UploadStoryViewModel(private val repository: StoryRepository) : ViewModel() {
    val imageUri = MutableLiveData<Uri?>()

    fun setImageUri(uri: Uri?) {
        imageUri.value = uri
    }

    fun uploadStory(file: File, description: String, currentLat: Float?, currentLon: Float?) =
        repository.uploadStory(file, description, currentLat, currentLon)

    companion object {
        private const val TAG = "UploadStoryViewModel"
    }
}