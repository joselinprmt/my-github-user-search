package com.dicoding.mystoryapp.view.auth.login

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.databinding.ActivityLoginBinding
import com.dicoding.mystoryapp.util.wrapEspressoIdlingResource
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.main.MainActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loginViewModel = obtainViewModel(this)

        loginViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        wrapEspressoIdlingResource {
            loginViewModel.fetchedResponse.observe(this) {
                if (it.error == true) {
                    showDialogue("Terjadi error: ${it.message}. Mohon periksa kembali input yang dimasukkan.")
                } else {
                    val intent = Intent(this, MainActivity::class.java)
                    showToast("Login berhasil")
                    startActivity(intent)
                    finish()
                }
            }


            binding.buttonLogin.setOnClickListener {
                val email = binding.edLoginEmail.text.toString()
                val password = binding.edLoginPassword.text.toString()

                // Validasi request sebelum data dikirim ke server
                validateRequest(email, password)
            }
        }
    }

    private fun validateRequest(email: String, password: String) {
        // Validasi email
        if (TextUtils.isEmpty(email)) {
            binding.edLoginEmail.error = "Email tidak boleh kosong"
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.edLoginEmail.error = "Masukkan email yang valid"
        }

        // Validasi password
        if (password.length < 8) {
            binding.edLoginPassword.error = "Password tidak boleh kurang dari 8 karakter"
        }

        loginViewModel.login(email, password)
    }

    private fun showDialogue(message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Login Gagal")
        builder.setMessage(message)
        builder.setNegativeButton("Coba Lagi") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun obtainViewModel(activity: AppCompatActivity): LoginViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[LoginViewModel::class.java]
    }
}