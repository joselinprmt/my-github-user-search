package com.dicoding.mystoryapp.view.auth.register

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.mystoryapp.data.remote.response.RegisterResponse
import com.dicoding.mystoryapp.data.remote.retrofit.ApiConfig
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterViewModel : ViewModel()  {
    val isLoading = MutableLiveData<Boolean>()
    val fetchedResponse = MutableLiveData<RegisterResponse>()

    companion object{
        private const val TAG = "RegisterViewModel"
    }

    fun register(name: String, email: String, password: String) {
        isLoading.value = true
        val client = ApiConfig.getApiService().register(name, email, password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                isLoading.value = false
                if (response.isSuccessful) {
                    fetchedResponse.value = response.body()
                } else {
                    val errorBody = response.errorBody()?.string()
                    if (errorBody != null) {
                        try {
                            val gson = Gson()
                            val errorResponse = gson.fromJson(errorBody, RegisterResponse::class.java)
                            fetchedResponse.value = errorResponse
                            Log.e(TAG, "onFailure: ${errorResponse.message}")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to parse error body", e)
                        }
                    } else {
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
                }
            }
            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }
        })
    }
}