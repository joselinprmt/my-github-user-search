package com.dicoding.mystoryapp.view.main

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.databinding.ActivityMainBinding
import com.dicoding.mystoryapp.util.wrapEspressoIdlingResource
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.onboarding.OnboardingActivity
import com.dicoding.mystoryapp.view.story.list.ListStoryActivity
import com.dicoding.mystoryapp.view.story.map.MapsActivity

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel
    private var name = "User"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        wrapEspressoIdlingResource {
            mainViewModel = obtainViewModel(this)
            mainViewModel.getSession().observe(this) { user ->
                if (user.isLogin) {
                    name = user.name
                    setupView(name)
                } else {
                    startActivity(Intent(this, OnboardingActivity::class.java))
                    finish()
                }
            }

            playAnimation()
        }
    }

    private fun setupView(name: String) {
        binding.heading.text = binding.root.context.getString(
            R.string.greeting,
            name
        )

        binding.listStoryButton.setOnClickListener {
            startActivity(Intent(this, ListStoryActivity::class.java))
        }

        binding.mapsButton.setOnClickListener {
            startActivity(Intent(this, MapsActivity::class.java))
        }

        binding.actionLogout.setOnClickListener {
            mainViewModel.logout()
        }
    }

    private fun obtainViewModel(activity: AppCompatActivity): MainViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[MainViewModel::class.java]
    }

    private fun playAnimation() {
        val img = ObjectAnimator.ofFloat(binding.imageView, View.ALPHA, 1f).setDuration(300)
        val heading = ObjectAnimator.ofFloat(binding.heading, View.ALPHA, 1f).setDuration(300)
        val subheading = ObjectAnimator.ofFloat(binding.subheading, View.ALPHA, 1f).setDuration(300)
        val listStoryButton = ObjectAnimator.ofFloat(binding.listStoryButton, View.ALPHA, 1f).setDuration(300)
        val mapsButton = ObjectAnimator.ofFloat(binding.mapsButton, View.ALPHA, 1f).setDuration(300)
        val actionLogout = ObjectAnimator.ofFloat(binding.actionLogout, View.ALPHA, 1f).setDuration(300)

        val texts = AnimatorSet().apply {
            playTogether(heading, subheading)
        }

        AnimatorSet().apply {
            playSequentially(img, texts, listStoryButton, mapsButton, actionLogout)
            start()
        }
    }
}