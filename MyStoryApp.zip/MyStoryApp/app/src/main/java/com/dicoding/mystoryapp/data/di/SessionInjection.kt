package com.dicoding.mystoryapp.data.di

import android.content.Context
import com.dicoding.mystoryapp.data.local.pref.UserPreference
import com.dicoding.mystoryapp.data.local.pref.dataStore
import com.dicoding.mystoryapp.data.repository.UserRepository

object SessionInjection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        return UserRepository.getInstance(pref)
    }
}