package com

import com.dicoding.mystoryapp.data.remote.response.StoryItem

object DataDummy {
    fun generateDummyStoryResponse(): List<StoryItem> {
        val storyList = ArrayList<StoryItem>()
        for (i in 0..10) {
            val story = StoryItem(
                "story-${i+1}",
                "Author",
                "This is description",
                "https://fakeimg.pl/300/",
            )
            storyList.add(story)
        }
        return storyList
    }
}