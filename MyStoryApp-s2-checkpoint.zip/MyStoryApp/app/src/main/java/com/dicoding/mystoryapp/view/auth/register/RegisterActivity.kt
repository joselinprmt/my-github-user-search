package com.dicoding.mystoryapp.view.auth.register

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.databinding.ActivityRegisterBinding
import com.dicoding.mystoryapp.view.auth.login.LoginActivity

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var registerViewModel: RegisterViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        registerViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        )[RegisterViewModel::class.java]

        registerViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        registerViewModel.fetchedResponse.observe(this) {
            if (it.error == true) {
                showDialogue(isError = true, "Terjadi error: ${it.message}. Mohon periksa kembali input yang dimasukkan.")
            } else {
                showDialogue(isError = false, "Silahkan login untuk melanjutkan.")
            }
        }

        binding.buttonRegister.setOnClickListener{
            val name = binding.edRegisterName.text.toString()
            val email = binding.edRegisterEmail.text.toString()
            val password = binding.edRegisterPassword.text.toString()

            // Validasi request sebelum data dikirim ke server
            validateRequest(name, email, password)
        }
    }

    private fun validateRequest(name: String, email: String, password: String) {
        // Validasi nama
        if (TextUtils.isEmpty(name)) {
            binding.edRegisterName.error = "Nama tidak boleh kosong"
            binding.edRegisterName.requestFocus()
        }

        // Validasi email
        if (TextUtils.isEmpty(email)) {
            binding.edRegisterEmail.error = "Email tidak boleh kosong"
            binding.edRegisterEmail.requestFocus()
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.edRegisterEmail.error = "Masukkan email yang valid"
            binding.edRegisterEmail.requestFocus()
        }

        // Validasi password
        if (password.length < 8) {
            binding.edRegisterPassword.error = "Password tidak boleh kurang dari 8 karakter"
            binding.edRegisterPassword.requestFocus()
        }

        registerViewModel.register(name, email, password)
    }

    private fun showDialogue(isError: Boolean, message: String) {
        val builder = AlertDialog.Builder(this)
        if (isError) {
            builder.setTitle("Register Gagal")
            builder.setMessage(message)
            builder.setNegativeButton("Coba Lagi") { dialog, _ ->
                dialog.dismiss()
            }
        } else {
            builder.setTitle("Register Berhasil")
            builder.setMessage(message)
            builder.setPositiveButton("Login") { _, _ ->
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish() // untuk menutup register activity
            }
            builder.setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
        }

        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}