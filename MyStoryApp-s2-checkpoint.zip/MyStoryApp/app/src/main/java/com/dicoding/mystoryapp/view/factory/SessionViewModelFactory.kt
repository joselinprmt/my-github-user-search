package com.dicoding.mystoryapp.view.factory

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.data.di.SessionInjection
import com.dicoding.mystoryapp.data.repository.UserRepository
import com.dicoding.mystoryapp.view.auth.login.LoginViewModel
import com.dicoding.mystoryapp.view.main.MainViewModel
import com.dicoding.mystoryapp.view.onboarding.OnboardingViewModel

class SessionViewModelFactory(private val repository: UserRepository) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(LoginViewModel::class.java) -> {
                LoginViewModel(repository) as T
            }
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(repository) as T
            }
            modelClass.isAssignableFrom(OnboardingViewModel::class.java) -> {
                OnboardingViewModel(repository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: SessionViewModelFactory? = null
        @JvmStatic
        fun getInstance(context: Context): SessionViewModelFactory {
            if (INSTANCE == null) {
                synchronized(SessionViewModelFactory::class.java) {
                    INSTANCE = SessionViewModelFactory(SessionInjection.provideRepository(context))
                }
            }
            return INSTANCE as SessionViewModelFactory
        }
    }
}