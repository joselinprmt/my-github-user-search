package com.dicoding.mystoryapp.view.onboarding

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.databinding.ActivityOnboardingBinding
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.auth.login.LoginActivity
import com.dicoding.mystoryapp.view.main.MainActivity
import com.dicoding.mystoryapp.view.auth.register.RegisterActivity

class OnboardingActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var onboardingViewModel: OnboardingViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        onboardingViewModel = obtainViewModel(this)
        onboardingViewModel.getSession().observe(this) { user ->
            if (user.isLogin) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
        }
        setupAuth()
        playAnimation()
    }

    private fun setupAuth() {
        binding.loginButton.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        binding.registerButton.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun playAnimation(){
        val img = ObjectAnimator.ofFloat(binding.imageView, View.ALPHA, 1f).setDuration(300)
        val heading = ObjectAnimator.ofFloat(binding.heading, View.ALPHA, 1f).setDuration(300)
        val subheading = ObjectAnimator.ofFloat(binding.subheading, View.ALPHA, 1f).setDuration(300)
        val loginButton = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(300)
        val registerButton = ObjectAnimator.ofFloat(binding.registerButton, View.ALPHA, 1f).setDuration(300)

        val texts = AnimatorSet().apply {
            playTogether(heading, subheading)
        }

        val buttons = AnimatorSet().apply {
            playTogether(loginButton, registerButton)
        }

        AnimatorSet().apply {
            playSequentially(img, texts, buttons)
            start()
        }
    }

    private fun obtainViewModel(activity: AppCompatActivity): OnboardingViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[OnboardingViewModel::class.java]
    }
}