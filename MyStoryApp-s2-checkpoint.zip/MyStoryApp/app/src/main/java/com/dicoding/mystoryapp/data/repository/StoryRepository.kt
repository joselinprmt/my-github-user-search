package com.dicoding.mystoryapp.data.repository

import android.util.Log
import androidx.lifecycle.liveData
import com.dicoding.mystoryapp.data.ResultState
import com.dicoding.mystoryapp.data.remote.response.FileUploadResponse
import com.dicoding.mystoryapp.data.remote.response.ListStoryItem
import com.dicoding.mystoryapp.data.remote.retrofit.ApiService
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.HttpException
import java.io.File

class StoryRepository (
    private val apiService: ApiService,
    private val dispatcher: CoroutineDispatcher = Dispatchers.Default
) {

    suspend fun getStories(token: String) : List<ListStoryItem?>? {
        return withContext(dispatcher) {
            try {
                val response = apiService.getStories("Bearer $token")
                response.listStory
            } catch (e: Exception) {
                Log.e(TAG, "onError: ${e.message}", e)
                emptyList<ListStoryItem>()
            }
        }
    }
    suspend fun getStoriesWithLocation(token: String): List<ListStoryItem?>? {
        return withContext(dispatcher) {
            try {
                val response = apiService.getStoriesWithLocation("Bearer $token")
                response.listStory
            } catch (e: Exception) {
                Log.e(TAG, "onError: ${e.message}", e)
                emptyList<ListStoryItem>()
            }
        }
    }

    fun uploadStory(token: String, imageFile: File, description: String) = liveData {
        emit(ResultState.Loading)
        val requestBody = description.toRequestBody("text/plain".toMediaType())
        val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
        val multipartBody = MultipartBody.Part.createFormData(
            "photo",
            imageFile.name,
            requestImageFile
        )
        try {
            val successResponse = apiService.uploadStory("Bearer $token", multipartBody, requestBody)
            emit(ResultState.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, FileUploadResponse::class.java)
            emit(ResultState.Error(errorResponse.message))
        }
    }

    companion object {
        @Volatile
        private var instance: StoryRepository? = null
        fun getInstance(apiService: ApiService): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository(apiService)
            }.also { instance = it }

        private const val TAG = "StoryRepository"
    }
}