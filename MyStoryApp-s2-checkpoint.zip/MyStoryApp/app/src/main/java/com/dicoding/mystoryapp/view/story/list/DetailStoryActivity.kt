package com.dicoding.mystoryapp.view.story.list

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.databinding.ActivityDetailStoryBinding
import com.dicoding.mystoryapp.view.story.map.MapsActivity

class DetailStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailStoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val name = intent.getStringExtra("name") ?: "User"
        val description = intent.getStringExtra("description") ?: "Description"
        val photoUrl = intent.getStringExtra("photo") ?: ""

        initToolbar()
        setupView(name, description, photoUrl)
    }

    private fun initToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
        binding.toolbar.findViewById<ImageButton>(R.id.action_maps).setOnClickListener {
            startActivity(Intent(this, MapsActivity::class.java))
        }
    }

    private fun setupView(name: String, description: String, photoUrl: String) {
        binding.tvDetailName.text = binding.root.context.getString(
            R.string.writer,
            name
        )
        binding.tvDetailDescription.text = description

        Glide.with(binding.root.context)
            .load(photoUrl)
            .into(binding.ivDetailPhoto)
    }
}