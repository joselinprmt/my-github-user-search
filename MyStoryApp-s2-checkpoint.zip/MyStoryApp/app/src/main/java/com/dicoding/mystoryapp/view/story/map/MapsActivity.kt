package com.dicoding.mystoryapp.view.story.map

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.data.remote.response.ListStoryItem
import com.dicoding.mystoryapp.databinding.ActivityMapsBinding
import com.dicoding.mystoryapp.view.auth.login.LoginViewModel
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.factory.StoryViewModelFactory
import com.dicoding.mystoryapp.view.onboarding.OnboardingActivity
import com.dicoding.mystoryapp.view.story.list.ListStoryActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var mapsViewModel: MapsViewModel
    private lateinit var loginViewModel: LoginViewModel
    private val boundsBuilder = LatLngBounds.Builder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loginViewModel = obtainLoginViewModel(this@MapsActivity)
        initToolbar()

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        observeSession()
    }

    private fun initToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
        binding.toolbar.findViewById<ImageButton>(R.id.action_story).setOnClickListener {
            startActivity(Intent(this, ListStoryActivity::class.java))
        }
    }

    private fun observeSession() {
        loginViewModel.getSession().observe(this) { it ->
            if (!it.isLogin) {
                val intent = Intent(this, OnboardingActivity::class.java)
                startActivity(intent)
            } else {
                mapsViewModel = obtainMapsViewModel(this@MapsActivity)
                mapsViewModel.getStoriesWithLocation(it.token)
                mapsViewModel.setMarker().observe(this) { stories ->
                    showStoryMarkers(stories)
                }
                mapsViewModel.isLoading.observe(this) { isLoading ->
                    showLoading(isLoading)
                }
            }
        }
    }

    private fun showStoryMarkers(stories: List<ListStoryItem?>) {
        stories.forEach { data ->
            val latLng = LatLng(data?.lat!!, data.lon!!)
            mMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title(data.name)
                    .snippet(data.description)
            )
            boundsBuilder.include(latLng)
        }

        val bounds: LatLngBounds = boundsBuilder.build()
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngBounds(
                bounds,
                resources.displayMetrics.widthPixels,
                resources.displayMetrics.heightPixels,
                300
            )
        )
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun obtainLoginViewModel(activity: AppCompatActivity): LoginViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[LoginViewModel::class.java]
    }

    private fun obtainMapsViewModel(activity: AppCompatActivity): MapsViewModel {
        val factory = StoryViewModelFactory.getInstance()
        return ViewModelProvider(activity, factory)[MapsViewModel::class.java]
    }
}