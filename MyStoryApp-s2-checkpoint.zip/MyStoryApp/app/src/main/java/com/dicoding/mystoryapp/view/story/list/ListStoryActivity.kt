package com.dicoding.mystoryapp.view.story.list

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.mystoryapp.R
import com.dicoding.mystoryapp.data.remote.response.ListStoryItem
import com.dicoding.mystoryapp.databinding.ActivityListStoryBinding
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.factory.StoryViewModelFactory
import com.dicoding.mystoryapp.view.auth.login.LoginViewModel
import com.dicoding.mystoryapp.view.onboarding.OnboardingActivity
import com.dicoding.mystoryapp.view.story.map.MapsActivity
import com.dicoding.mystoryapp.view.story.upload.UploadStoryActivity

class ListStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListStoryBinding
    private lateinit var listStoryViewModel: ListStoryViewModel
    private lateinit var loginViewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListStoryBinding.inflate(layoutInflater)
        loginViewModel = obtainLoginViewModel(this@ListStoryActivity)
        setContentView(binding.root)

        observeSession()
        initAction()
        initRecycleView()
    }

    override fun onResume() {
        super.onResume()
        observeSession()
    }

    private fun observeSession() {
        loginViewModel.getSession().observe(this) {
            if (!it.isLogin) {
                val intent = Intent(this, OnboardingActivity::class.java)
                startActivity(intent)
            } else {
                listStoryViewModel = obtainStoryViewModel(this@ListStoryActivity)
                listStoryViewModel.getStory(it.token)

                listStoryViewModel.stories.observe(this) { stories ->
                    checkSize(stories)
                    setStoryData(stories)
                }
                listStoryViewModel.isLoading.observe(this) { isLoading ->
                    showLoading(isLoading)
                }
            }
        }
    }

    private fun initRecycleView() {
        val layoutManager = LinearLayoutManager(this)
        binding.rvStory.layoutManager = layoutManager
    }

    private fun setStoryData(users: List<ListStoryItem?>?) {
        val adapter = StoryAdapter()
        adapter.submitList(users)
        binding.rvStory.adapter = adapter
    }

    private fun initAction() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
        binding.toolbar.findViewById<ImageButton>(R.id.action_maps).setOnClickListener {
            startActivity(Intent(this, MapsActivity::class.java))
        }

        val fab = binding.fab
        fab.setOnClickListener { _ ->
            val intent = Intent(this, UploadStoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun checkSize(list: List<ListStoryItem?>) {
        if (list.isEmpty()) {
            binding.tvNoStoryData.visibility = View.VISIBLE
        } else {
            binding.tvNoStoryData.visibility = View.GONE
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.tvNoStoryData.visibility = View.GONE
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun obtainLoginViewModel(activity: AppCompatActivity): LoginViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[LoginViewModel::class.java]
    }

    private fun obtainStoryViewModel(activity: AppCompatActivity): ListStoryViewModel {
        val factory = StoryViewModelFactory.getInstance()
        return ViewModelProvider(activity, factory)[ListStoryViewModel::class.java]
    }
}