package com.dicoding.mystoryapp.view.story.upload

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mystoryapp.data.ResultState
import com.dicoding.mystoryapp.databinding.ActivityUploadStoryBinding
import com.dicoding.mystoryapp.view.factory.SessionViewModelFactory
import com.dicoding.mystoryapp.view.factory.StoryViewModelFactory
import com.dicoding.mystoryapp.view.auth.login.LoginViewModel
import com.dicoding.mystoryapp.view.onboarding.OnboardingActivity
import com.dicoding.mystoryapp.util.getImageUri
import com.dicoding.mystoryapp.util.reduceFileImage
import com.dicoding.mystoryapp.util.uriToFile

class UploadStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUploadStoryBinding
    private lateinit var uploadStoryViewModel: UploadStoryViewModel
    private lateinit var loginViewModel: LoginViewModel
    private var currentImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loginViewModel = obtainLoginViewModel(this@UploadStoryActivity)
        uploadStoryViewModel = obtainUploadViewModel(this@UploadStoryActivity)

        binding.galleryButton.setOnClickListener { startGallery() }
        binding.cameraButton.setOnClickListener { startCamera() }
        binding.buttonAdd.setOnClickListener { observeToken() }

        uploadStoryViewModel.imageUri.observe(this) { uri ->
            uri?.let {
                binding.previewImageView.setImageURI(it)
            }
        }
    }

    private fun startGallery() {
        launcherGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            uploadStoryViewModel.setImageUri(uri)
            currentImageUri = uri
            showImage()
        } else {
            Log.d("Photo Picker", "No media selected")
        }
    }

    private fun startCamera() {
        currentImageUri = getImageUri(this)
        launcherIntentCamera.launch(currentImageUri)
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { isSuccess ->
        if (isSuccess) {
            showImage()
        }
    }

    private fun showImage() {
        currentImageUri?.let {
            Log.d("Image URI", "showImage: $it")
            binding.previewImageView.setImageURI(it)
        }
    }

    private fun observeToken() {
        loginViewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                showToast("Silakan login terlebih dahulu")
                val intent = Intent(this, OnboardingActivity::class.java)
                startActivity(intent)
            } else {
                uploadStory(user.token)
            }
        }
    }

    private fun uploadStory(token: String) {
        currentImageUri?.let { uri ->
            val imageFile = uriToFile(uri, this).reduceFileImage()
            Log.d("Image File", "showImage: ${imageFile.path}")
            val description = binding.edAddDescription.text.toString()
            uploadStoryViewModel.uploadStory(token, imageFile, description).observe(this) { result ->
                if (result != null) {
                    when (result) {
                        is ResultState.Loading -> {
                            showLoading(true)
                        }
                        is ResultState.Success -> {
                            showToast(result.data.message)
                            showLoading(false)
                            finish()
                        }
                        is ResultState.Error -> {
                            showToast(result.error)
                            showLoading(false)
                        }
                    }
                }
            }
        } ?: showToast("Gambar kosong")
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun obtainUploadViewModel(activity: AppCompatActivity): UploadStoryViewModel {
        val factory = StoryViewModelFactory.getInstance()
        return ViewModelProvider(activity, factory)[UploadStoryViewModel::class.java]
    }

    private fun obtainLoginViewModel(activity: AppCompatActivity): LoginViewModel {
        val factory = SessionViewModelFactory.getInstance(activity.application)
        return ViewModelProvider(activity, factory)[LoginViewModel::class.java]
    }
}