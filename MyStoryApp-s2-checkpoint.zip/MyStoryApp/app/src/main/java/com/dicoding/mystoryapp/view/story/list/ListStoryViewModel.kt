package com.dicoding.mystoryapp.view.story.list

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.mystoryapp.data.remote.response.ListStoryItem
import com.dicoding.mystoryapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class ListStoryViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    val isLoading = MutableLiveData<Boolean>()
    val stories = MutableLiveData<List<ListStoryItem?>>()

    companion object {
        private const val TAG = "ListStoryViewModel"
    }

    fun getStory(token: String) {
        isLoading.value = true

        viewModelScope.launch {
            stories.value = storyRepository.getStories(token)
            isLoading.value = false
        }
    }
}