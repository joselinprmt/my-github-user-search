package com.dicoding.mystoryapp.data.di

import com.dicoding.mystoryapp.data.remote.retrofit.ApiService
import com.dicoding.mystoryapp.data.repository.StoryRepository

object StoryInjection {
    fun provideRepository(apiService: ApiService): StoryRepository {
        return StoryRepository.getInstance(apiService)
    }
}