package com.dicoding.mystoryapp.view.story.map

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.mystoryapp.data.remote.response.ListStoryItem
import com.dicoding.mystoryapp.data.repository.StoryRepository
import kotlinx.coroutines.launch

class MapsViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    val isLoading = MutableLiveData<Boolean>()
    private val stories = MutableLiveData<List<ListStoryItem?>>()

    fun getStoriesWithLocation(token: String) {
        isLoading.value = true

        viewModelScope.launch {
            stories.value = storyRepository.getStoriesWithLocation(token)
            isLoading.value = false
        }
    }

    fun setMarker(): MutableLiveData<List<ListStoryItem?>> {
        return stories
    }
}